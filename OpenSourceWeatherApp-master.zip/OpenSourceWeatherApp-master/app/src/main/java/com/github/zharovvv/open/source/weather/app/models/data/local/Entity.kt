package com.github.zharovvv.open.source.weather.app.models.data.local

interface Entity {
    val id: Int
}