package com.github.zharovvv.open.source.weather.app.models.presentation

class ChooseCityAutoUpdateBannerItem : DelegateAdapterItem {
    override val id: Any get() = "ChooseCityAutoUpdateBannerItem"
    override val content: Any get() = Unit
}
