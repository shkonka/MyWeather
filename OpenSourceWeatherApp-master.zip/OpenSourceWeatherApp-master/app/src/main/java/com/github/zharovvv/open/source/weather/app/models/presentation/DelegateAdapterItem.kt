package com.github.zharovvv.open.source.weather.app.models.presentation

interface DelegateAdapterItem {
    val id: Any
    val content: Any
}