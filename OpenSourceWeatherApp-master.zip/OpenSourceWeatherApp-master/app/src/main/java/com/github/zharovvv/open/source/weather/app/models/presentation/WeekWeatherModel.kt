package com.github.zharovvv.open.source.weather.app.models.presentation

/**
 * Модель списка ежедневного прогназа погоды
 */
data class WeekWeatherModel(
    val items: List<WeekWeatherItemModel>
)