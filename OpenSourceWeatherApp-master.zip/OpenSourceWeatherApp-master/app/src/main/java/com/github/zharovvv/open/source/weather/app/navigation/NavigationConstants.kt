package com.github.zharovvv.open.source.weather.app.navigation

const val LOCATION_PERMISSION_EXPLANATION_DIALOG_RESULT_KEY =
    "LOCATION_PERMISSION_EXPLANATION_DIALOG_RESULT_KEY"